How to run:

1. Open terminal inside this folder.
2. Run:
   python main.py

3. To run tests:
   python -m unittest tests/test_analyser.py

The file students.csv is already included.
The result will be saved into output/result.json.
