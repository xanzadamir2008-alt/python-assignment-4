import os


class FileManager:
    def __init__(self, filename):
        self.filename = filename

    def check_file(self):
        if not os.path.exists(self.filename):
            print(f"File {self.filename} not found")
            return False

        print(f"File {self.filename} found")
        return True

    def create_output_folder(self):
        if not os.path.exists("output"):
            os.makedirs("output")
            print("Output folder created")
