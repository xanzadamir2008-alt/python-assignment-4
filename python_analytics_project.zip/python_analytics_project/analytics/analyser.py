class DataAnalyser:
    def __init__(self, students):
        self.students = students
        self.result = {}

    def analyse(self):
        print("Not implemented - use a child class")

    def print_results(self):
        for key, value in self.result.items():
            print(f"{key}: {value}")

    def __str__(self):
        return f"DataAnalyser: base class, {len(self.students)} students"


class GpaAnalyser(DataAnalyser):
    def __init__(self, students):
        super().__init__(students)

    def analyse(self):
        total_students = len(self.students)

        gpas = []
        for student in self.students:
            gpas.append(float(student["GPA"]))

        average_gpa = round(sum(gpas) / total_students, 2)
        max_gpa = max(gpas)
        min_gpa = min(gpas)

        high_performers = 0
        for gpa in gpas:
            if gpa >= 3.5:
                high_performers += 1

        self.result = {
            "total_students": total_students,
            "average_gpa": average_gpa,
            "max_gpa": max_gpa,
            "min_gpa": min_gpa,
            "high_performers": high_performers
        }

    def print_results(self):
        print("==============================")
        print("GPA ANALYSIS REPORT")
        print("==============================")
        super().print_results()
        print("==============================")

    def __str__(self):
        return f"GpaAnalyser: GPA Statistics, {len(self.students)} students"


class CountryAnalyser(DataAnalyser):
    def __init__(self, students):
        super().__init__(students)

    def analyse(self):
        countries = {}

        for student in self.students:
            country = student["country"]
            countries[country] = countries.get(country, 0) + 1

        top_3 = sorted(countries.items(), key=lambda x: x[1], reverse=True)[:3]

        self.result = {
            "total_students": len(self.students),
            "total_countries": len(countries),
            "top_3": top_3,
            "all_countries": countries
        }

    def print_results(self):
        print("==============================")
        print("COUNTRY ANALYSIS REPORT")
        print("==============================")
        super().print_results()
        print("==============================")

    def __str__(self):
        return f"CountryAnalyser: Country Analysis, {len(self.students)} students"
