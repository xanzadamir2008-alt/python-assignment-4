from analytics import FileManager, DataLoader, GpaAnalyser, CountryAnalyser, ResultSaver, Report


fm = FileManager("students.csv")
fm.check_file()
fm.create_output_folder()

dl = DataLoader("students.csv")
dl.load()
dl.preview()

students = dl.students

analysers = [
    GpaAnalyser(students),
    CountryAnalyser(students)
]

print("------------------------------")
print("Running all analysers:")
print("------------------------------")

for analyser in analysers:
    print(analyser)
    analyser.analyse()
    analyser.print_results()

analyser = GpaAnalyser(students)
saver = ResultSaver(analyser.result, "output/result.json")
report = Report(analyser, saver)
report.generate()
